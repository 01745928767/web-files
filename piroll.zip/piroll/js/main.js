// (function ($) {
//     "use strict";
// }) (jQurey);
// slider owl-carousel
$(document).ready(function(){
    // mean menu
    jQuery('#mobile-menu').meanmenu({
        meanMenuContainer: '.mobile-menu',
        meanScreenWidth: '767',
    });
    // slider active
    $('.slider-active').owlCarousel({
        loop:true,
        margin:0,
        nav:false,
        dots:false,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    });
    // testimonial active
    $('.testimonial-active').owlCarousel({
        loop:true,
        margin:0,
        nav:false,
        dots:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    });
    // brand active
    $('.brand-active').owlCarousel({
        loop:true,
        margin:0,
        nav:false,
        dots:false,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:3
            },
            1000:{
                items:4
            }
        }
    });
    // wow active
    // counter up
    $('.counter').counterUp({
        delay: 10,
        time: 1000
    });
    // portfolio image popup
    $('.video-popup').magnificPopup({
        type: 'image'
        // other options
    });
    // video popup
    $('.work-video-popup').magnificPopup({
        type: 'image'
        // other options
    });
});