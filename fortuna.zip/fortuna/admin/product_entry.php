<html>
	<?php session_start();?>
	<?php require_once('../connection.php');?>
	<?php require_once('header.php');?>
	
	<?php
			if(!empty($_POST['submit'])){

				$dir='../images/';
					$rand=rand(0,9999999);
					$file=$_FILES['photo']['name'];
					$pic=$dir.$rand.$file;
					$upload=move_uploaded_file($_FILES['photo']['tmp_name'],$pic);

				$category=trim($_POST['category']);
				$type=trim($_POST['type']);
				$size=trim($_POST['size']);
				$color=trim($_POST['color']);
				$price=trim($_POST['price']);
					
					$dt=new DateTime('now',new DateTimezone('Asia/Dhaka'));
					$date=$dt->format('Y-m-d');
					$time=$dt->format('h:i:s a');
					
					$sql=mysql_query("insert into shoes values(
								'',
								'$pic',
								'$category',
								'$type',
								'$size',
								'$color',
								'$price',
								'$date',
								'$time'
					)");
					
					if(!$sql){					
						echo"error".mysql_error();			
							}			
					else{	
					echo"<script>alert('Entry successfully')</script>";
					echo"<script>location.href='product_entry.php'</script>";
						}
											
					}
	?>
	
	<body>
	<div class='container form'>
            <form  method='post' action='' id='register' enctype='multipart/form-data'>
				<fieldset>
					<legend><h3>PRODUCT ENTRY</h3></legend>
                        <div class='middle'>

							<div class="form-file">
                                <label >Photo</label>
                                <input type="file" name='photo' id='file'>
                            </div>
                            
                            <div class="form-group">
                                <label for="category" class='label_design'>Category</label>
                                <select class="form-control" name='category' id='category' required>
									<option selected> men </option>
									<option> women </option>
									<option> kid </option>
								</select>
                            </div>
                            <div class="form-group">
                                <label for="category" class='label_design'>Type</label>
                                <select class="form-control" name='type' id='type' required>
									<option selected> shoes </option>
									<option> converse </option>
									<option> sandals </option>
                                    <option> punjabi </option>
									<option> shirt </option>
									<option> polo </option>
									<option> t-shirt </option>
									<option> bag </option>
								</select>
                            </div>

                            <div class="form-group">
                                <label class='label_design'>Size</label>
                                <input  type='text' name='size' class="form-control" placeholder="Size" required>
                            </div>
                            <div class="form-group">
                                <label class='label_design'>Color</label>
                                <input type='text' name='color' class="form-control" placeholder="Color" required>
                            </div>			
					        
				            <div class="form-group">
                                <label class='label_design'>Price</label>
                                <input type='text' name='price' id='price' class="form-control" placeholder="Price" required>
                            </div>
																		
                             <input type="submit" value='ENTRY' name='submit' class="form-group btn btn-default" required>
                                       
						</div>
				</fieldset>
			</form>    
	</div>
	
	
	<?php require_once('footer.php');?>
    </body>
</html>

