<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Fortuna</title>

        <link rel="stylesheet" href="../css/font-awesome.min.css" />
        <link href="../css/bootstrap.min.css" rel="stylesheet" />
        <link href="../css/style.css" rel="stylesheet" />
        <link href="../css/responsive.css" rel="stylesheet" />
    </head>
    <body>
        <?php require_once('header.php'); ?>
        <?php require_once('slider.php'); ?>
        
        <section class="content">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 col-md-4">
                        <div class="shoes_item">
                            <img src="../images/kids.jpg" >
                            <a href=""><h3>Kids Collection</h3></a>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-4">
                        <div class="shoes_item">
                            <img src="../images/women.jpg" >
                            <a href=""><h3>Womens Collection</h3></a>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-4">
                        <div class="shoes_item">
                            <img src="../images/men.jpg" >
                            <a href=""> <h3>Mens Collection</h3></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <?php require_once('footer.php'); ?>
    </body>
</html>
