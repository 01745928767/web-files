<html>
<?php
    session_start();
    require_once('../connection.php');
?>
<?php require_once('header.php');?>
    <div class='container'>
        <div class='my_cart'>
<?php
            $customer_id=$_SESSION['customer_id'];
            $product_id=$_GET['product_id'];
            $sql=mysql_query("select * from shoes,customer   
                    where (shoes.product_id='$product_id' and customer.customer_id='$customer_id')");
                    
            $data=mysql_fetch_array($sql);
            $photo=$data['photo'];
            $category=$data['category'];
            $type=$data['type'];
            $size=$data['size'];
            $color=$data['color'];
            $price=$data['price'];
            $name=$data['name'];
            $email=$data['email'];
            $phone=$data['phone'];
            $address=$data['address'];
            $city=$data['city'];
            $division=$data['division'];
            
            $dt=new DateTime('now',new DateTimezone('Asia/Dhaka'));
            $date=$dt->format('Y-m-d');
            $time=$dt->format('h:i:s a');
        
        echo"
        
        <div class='mycart_information'> 
            <form method='post' enctype='multipart/form-data'>
                <table border='5' width='600'>
                    <tr>
                        <th width='10%'>Product Id</th>
                        <td>$product_id</td>
                    </tr>
                    <tr>
                        <th width='15%'>Photo</th>
                        <td><img src='../images/$photo' style='height: 300px;width: 300px' /></td>
                    </tr>
                    <tr>
                        <th>Category</th>
                        <td>$category</td>
                    </tr>
                    <tr>
                        <th width='15%'>Type</th>
                        <td>$type</td>
                    </tr>
                    <tr>
                        <th>Size</th>
                        <td>$size</td>
                    </tr>
                    <tr>
                        <th>Color</th>
                        <td>$color</td>
                    </tr>
                    <tr>
                        <th>Price(Taka)</th>
                        <td>$price</td>
                    </tr>
                    <tr>
                        <th colspan='2' class='text-center'>Shipping Address</th>
                    </tr>
                    <tr>
                        <th>Address</th>
                        <td><input type='text' name='address' class='form-control' value='$address'/></td>
                    </tr>
                    <tr>
                        <th>City</th>
                        <td><input type='text' name='city' class='form-control' value='$city'/></td>
                    </tr>
                    <tr>
                        <th>Division</th>
                        <td><input type='text' name='division' class='form-control' value='$division'/></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type='submit' value='Purchase' name='submit' class='btn btn-success'></td>
                    </tr>  
                        
                    
                </table>
            </form>
        </div>
        ";
        if(!empty($_POST['submit'])){
                $issue_date=trim($_POST['issue_date']);
                $expiry_date=trim($_POST['expiry_date']);
                
                    $sql=mysql_query("insert into purchase values(
                                '',
                                '$product_id',
                                '$photo',
                                '$category',
                                '$type',
                                '$size',
                                '$color',
                                '$price',
                                '$customer_id',
                                '$name',
                                '$email',
                                '$phone',
                                '$address',
                                '$city',
                                '$division',
                                '$date',
                                '$time'   
                    )");
                    
                    if(!$sql){                  
                        echo"error".mysql_error();          
                            }           
                    else{   
                            if($sql){
                                echo"<script>alert('Purchase Successfull. Please send payment to our bkash number & give us a sms with your bcash number & email. You will get your product soon. Thanks a lot. ----> Bkash Number : 01516184740.')</script>";
                                echo"<script>location.href='index.php'</script>";
                            }
                            else{
                                echo"<script>alert('issue not successfully')</script>";
                                echo"<script>location.href='mycart.php'</script>";
                            }
                        }
                    }
                    
?>
</div>
        
    </div>
    <?php require_once('footer.php');?>

    <script type="text/javascript" src="../js/jquery-3.1.0.js"></script>
        <script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>