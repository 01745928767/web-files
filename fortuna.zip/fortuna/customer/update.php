<html>
<?php
    session_start();
    require_once('../connection.php');
?>
    <?php require_once('header.php');?>
    <div class='container update_content'>
            <div class='row'>
                <div class='col-md-9'>
                    <form method='post' enctype="multipart/form-data">
					   <table align="center"  cellspacing='0' cellpadding="15" border="1" width='90%'>
                            <?php
                                $customer_id=$_SESSION['customer_id'];
                                $sql=mysql_query("select * from customer where customer_id='$customer_id'");
                                while($data=mysql_fetch_array($sql)){
                                    $name=$data['name'];
                                    $email=$data['email'];
                                    $password=$data['password'];
                                    $phone=$data['phone'];
                                    $address=$data['address'];
                                    $zip_code=$data['zip_code'];
                                    $city=$data['city'];
                                    $division=$data['division'];
                                    
                                    print "<h2 class='text-center'>ALL Information</h2>";
                                    print "<tr><td> Name </td>	<td><input type='text' name='name' value='$name'/></td></tr>";
                                    print "<tr><td> Email </td>	<td><input type='email' name='email' value='$email'/></td></tr>";
                                    print "<tr><td> Password </td>	<td><input type='text' name='password' value='$password'/></td></tr>";
                                    print "<tr><td> Phone </td>	<td><input type='phone' name='phone' value='$phone'/></td></tr>";
                                    print "<tr><td> Mobile</td>	<td><input type='text' name='address' value='$address'/></td></tr>";
                                    print "<tr><td> City</td>	<td><input type='text' name='city' value='$city'/></td></tr>";
                                    print "<tr><td> Zipcode </td>	<td><input type='text' name='zip_code' value='$zip_code'/></td></tr>";
                                    print "<tr><td> Division </td>	<td><input type='text' name='division' value='$division'/></td></tr>";
                                    print "<tr><td></td>	<td><input type='submit' name='Submit' value='Submit'/></td></tr>";
                                    }
                                ?>
                           </table>
                    </form>
                    <?php
							if($_POST){
									
							$name=$_POST['name'];
							$email=$_POST['email'];
							$password=$_POST['password'];
                            $phone=$_POST['phone'];
                            $address=$_POST['address'];
                            $zip_code=$_POST['zip_code'];
                            $city=$_POST['city'];
                            $division=$_POST['division'];
							
							mysql_connect('localhost','root','') or die("error");
											
							mysql_select_db('fortuna');
							$sql=mysql_query("update customer set 
							name='$name',
							email='$email',
                            password='$password',
							phone='$phone',
                            address='$address',
                            zip_code='$zip_code',
                            city='$city',
                            division='$division'
							
							where customer_id='$customer_id'");
							
							if($sql){
								print "Successfully Updated ";
							}	
							else{
								print mysql_error();
							}
							
						}
							
							
					?>
                </div>

                <div class='col-md-3  text-center'>
                    <div class="col-md-12">
                        
                        <?php
                            $customer_id=$_SESSION['customer_id'];
                            $sql=mysql_query("select * from customer where customer_id='$customer_id'");
                            while($data=mysql_fetch_array($sql)){
                                $name=$data['name'];
                                $email=$data['email'];
                                $password=$data['password'];
                                $phone=$data['phone'];
                                $address=$data['address'];
                                $zip_code=$data['zip_code'];
                                $city=$data['city'];
                                $division=$data['division'];

                                echo"		
                                    <div class='customer_info'>
                                        <h4> $name </h4>
                                        <h4> $email </h4>
                                        <h4> $address </h4>
                                        <h4> $city </h4>
                                        <h4> $division </h4>
                                        <a href='purchased_item.php' class='btn-lg btn-success'>Purchased Item</a>
                                    </div>			
                                ";
                            }
                        ?>
                    </div>
                    
                </div>
        </div>    
    </div>
	<?php require_once('footer.php');?>

	   <script type="text/javascript" src="../js/jquery-3.1.0.js"></script>
        <script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>