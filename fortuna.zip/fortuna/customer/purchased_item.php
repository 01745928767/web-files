<html>
<?php
    session_start();
    require_once('../connection.php');
?>
    <?php require_once('header.php');?>
    <div class='container kids_content'>
            <div class='row'>
                <div class='col-md-9'>
                    <?php
                        $customer_id=$_SESSION['customer_id'];
                        $sql=mysql_query("select * from purchase where customer_id='$customer_id'");
                        while($data=mysql_fetch_array($sql)){
                            $photo=$data['photo'];
                            $product_id=$data['product_id'];
                            $price=$data['price'];
                            $color=$data['color'];
                            $size=$data['size'];
                            $date=$data['date'];

                            echo"		
                                <div class='kids_image'>
                                    <img src='../images/$photo' alt='there is a image'>
                                        <h4>Product_id : $product_id </h4>
                                        <h4>Price : $price </h4>
                                        <h4>Color : $color </h4>
                                        <h4>Size : $size </h4>
                                        <h4>Date : $date </h4>
                                </div>			
                            ";
                        }
                    ?>
                </div>


                <div class='col-md-3  text-center'>
                    <?php
                        $customer_id=$_SESSION['customer_id'];
                        $sql=mysql_query("select * from customer where customer_id='$customer_id'");
                        while($data=mysql_fetch_array($sql)){
                            $name=$data['name'];
                            $email=$data['email'];
                            $address=$data['address'];
                            $city=$data['city'];
                            $division=$data['division'];

                            echo"		
                                <div class='customer_info'>
                                        <h4> $name </h4>
                                        <h4> $email </h4>
                                        <h4> $address </h4>
                                        <h4> $city </h4>
                                        <h4> $division </h4>
                                        <ul class='list-unstyled'>
                                            <li><a href='purchased_item.php' class='btn btn-sm btn-success'>Purchased Item</a></li>
                                            <li><a href='update.php' class='btn btn-sm btn-danger'>Update Info.</a></li>
                                        </ul>
                                </div>			
                            ";
                        }
                    ?>
                </div>
        </div>    
    </div>
	<?php require_once('footer.php');?>

	    <script type="text/javascript" src="../js/jquery-3.1.0.js"></script>
        <script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>