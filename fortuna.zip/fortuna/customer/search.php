    <html>                  
		<?php session_start();?>
		<?php require_once('connection.php');?>
		<?php require_once('header.php');?>					
   <div class='container kids_content'>
		<div class='row'>
			<div class='col-md-12'>
			<?php
				if(!empty($_POST['search'])){
					$search=trim($_POST['name']);
					$sql=mysql_query("select * from shoes where (category='$search' or type='$search')");
					$count=mysql_num_rows($sql);
						if($count==0){
							echo"<font color='#aa0000'>Does not Match</font>";  
								  }
						 else{
							while($data=mysql_fetch_array($sql)){
								$photo=$data['photo'];
								$product_id=$data['product_id'];
								$color=$data['color'];
								$price=$data['price'];
							echo"
									<div class='kids_image'>
										<img src='../images/$photo' alt='there is a image'>
										<h3>Product Id : $product_id</h3>
										<h4>Color : $color</h4>
										<h4>Price : $price</h4>
										<a href='login.php' class='btn btn-info'>Buy</a>
									</div>
								";
									}
									  
								  }
                                                            }
			?> 
			</div>		
		</div>
	</div>
							
        
        <?php require_once('footer.php');?>
		<script src="js/jquery-3.1.0.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
</html>		
