<?php
    $con=mysql_connect('localhost','root','') or die('error'.mysql_error());
    $db=mysql_select_db('fortuna') or die('error'.mysql_error());
?>
