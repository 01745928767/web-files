<html>
<?php
    session_start();
    require_once('connection.php');
?>
    <?php require_once('header.php');?>
    <div class='container kids_content'>
            <div class='row'>
                <div class='col-md-9'>
                    <?php
                        $sql=mysql_query("select * from shoes where category='women'");
                        while($data=mysql_fetch_array($sql)){
                            $photo=$data['photo'];
                            $product_id=$data['product_id'];
                            $price=$data['price'];
                            $color=$data['color'];

                            echo"		
                                <div class='kids_image'>
                                    <img src='images/$photo' alt='there is a image'>
                                        <h4>Product_id : $product_id</h4>
                                        <h4>Price : $price</h4>
                                        <h4>Color: $color</h4>
                                        <a href='login.php' class='btn btn-info'>Buy</a>
                                </div>			
                            ";
                        }
                    ?>
                </div>


                    <div class='col-md-3 kids_text text-center'>
                        <ul>
                            <h2>Categories</h2>
                            <li><a href='kids.php'>Kids</a></li>
                            <li><a href='women.php'>Women</a></li>
                            <li><a href='men.php'>Men</a></li>
                        </ul>
                    </div>
        </div>    
    </div>
    
	<?php require_once('footer.php');?>
        <script type="text/javascript" src="js/jquery-3.1.0.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
</html>