-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2017 at 07:58 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fortuna`
--
CREATE DATABASE IF NOT EXISTS `fortuna` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `fortuna`;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(44) NOT NULL,
  `email` varchar(44) NOT NULL,
  `password` varchar(21) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(60) NOT NULL,
  `zip_code` int(7) NOT NULL,
  `city` varchar(44) NOT NULL,
  `division` varchar(44) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `name`, `email`, `password`, `phone`, `address`, `zip_code`, `city`, `division`) VALUES
(17, 'imran', 'imrancse@gmail.com', '12345', 1943900802, '11/a,house no.32,kandirpar', 3500, 'comilla', 'chittagong'),
(18, 'borhan', 'borhancse@gmail.com', '12345', 1813725607, 'house no.10,road 11/a,kandirpar', 1231, 'barura', 'chittagong');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE IF NOT EXISTS `purchase` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `category` varchar(44) NOT NULL,
  `type` varchar(44) NOT NULL,
  `size` int(11) NOT NULL,
  `color` varchar(44) NOT NULL,
  `price` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `name` varchar(44) NOT NULL,
  `email` varchar(44) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(60) NOT NULL,
  `city` varchar(44) NOT NULL,
  `division` varchar(44) NOT NULL,
  `date` varchar(44) NOT NULL,
  `time` varchar(44) NOT NULL,
  PRIMARY KEY (`purchase_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchase_id`, `product_id`, `photo`, `category`, `type`, `size`, `color`, `price`, `customer_id`, `name`, `email`, `phone`, `address`, `city`, `division`, `date`, `time`) VALUES
(5, 35, '../images/57382207412109men12.jpg', 'men', 'sandals', 15, 'black', 2150, 17, 'imran', 'imrancse@gmail.com', 1943900802, '11/a,house no.32,kandirpar', 'comilla', 'chittagong', '2016-10-25', '12:51:54 pm'),
(6, 36, '../images/7404785men9.jpg', 'men', 'converse', 15, 'black', 2150, 18, 'borhan', 'borhancse@gmail.com', 1813725607, 'house no.11,road 12/a,kandirpar', 'comilla', 'chittagong', '2016-10-25', '01:03:46 pm'),
(7, 22, '../images/5834045men14.jpg', 'men', 'sandals', 17, 'green', 1250, 18, 'borhan', 'borhancse@gmail.com', 1813725607, 'house no.11,road 12/a,kandirpar', 'comilla', 'chittagong', '2016-10-25', '01:04:32 pm'),
(8, 31, '../images/5834045men6.jpg', 'men', 'converse', 15, 'light blue', 2500, 17, 'imran', 'imrancse@gmail.com', 1943900802, '11/a,house no.32,kandirpar', 'comilla', 'chittagong', '2016-11-06', '09:50:03 pm'),
(9, 13, '../images/715332kids6.jpg', 'kid', 'converse', 5, 'light blue', 650, 18, 'borhan', 'borhancse@gmail.com', 1813725607, 'house no.10,road 11/a,kandirpar', 'barura', 'chittagong', '2017-04-20', '04:59:01 am');

-- --------------------------------------------------------

--
-- Table structure for table `shoes`
--

CREATE TABLE IF NOT EXISTS `shoes` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `photo` varchar(100) NOT NULL,
  `category` varchar(44) NOT NULL,
  `type` varchar(44) NOT NULL,
  `size` int(11) NOT NULL,
  `color` varchar(21) NOT NULL,
  `price` int(11) NOT NULL,
  `entry_date` date NOT NULL,
  `time` varchar(100) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `shoes`
--

INSERT INTO `shoes` (`product_id`, `photo`, `category`, `type`, `size`, `color`, `price`, `entry_date`, `time`) VALUES
(4, '../images/1685180bg1.png', 'men', 'sandals', 10, 'grey', 550, '2016-10-14', '04:33:32 pm'),
(5, '../images/536499bg3.png', 'men', 'converse', 11, 'grey', 950, '2016-10-15', '08:20:08 am'),
(6, '../images/7657470fp2.png', 'men', 'shoes', 12, 'black', 3200, '2016-10-16', '10:53:23 am'),
(7, '../images/6384277kids1.jpg', 'kid', 'converse', 7, 'red', 750, '2016-10-16', '07:14:16 pm'),
(8, '../images/903625kids2.jpg', 'kid', 'converse', 8, 'red', 850, '2016-10-16', '07:14:39 pm'),
(10, '../images/718994kids3.jpg', 'kid', 'converse', 7, 'purple', 750, '2016-10-16', '08:47:31 pm'),
(11, '../images/1169128kids4.jpg', 'kid', 'converse', 7, 'blue', 950, '2016-10-16', '08:48:48 pm'),
(12, '../images/2712707kids5.jpg', 'kid', 'converse', 5, 'white', 550, '2016-10-16', '08:55:22 pm'),
(13, '../images/715332kids6.jpg', 'kid', 'converse', 5, 'light blue', 650, '2016-10-16', '08:56:57 pm'),
(14, '../images/6402893women1.jpg', 'women', 'converse', 8, 'red', 1150, '2016-10-16', '11:56:19 pm'),
(15, '../images/4651489women2.jpg', 'women', 'converse', 9, 'blue', 1250, '2016-10-16', '11:57:26 pm'),
(16, '../images/1717224women3.jpg', 'women', 'converse', 11, 'grey', 1150, '2016-10-16', '11:58:02 pm'),
(17, '../images/476074women4.jpg', 'women', 'converse', 15, 'black', 1350, '2016-10-16', '11:58:40 pm'),
(18, '../images/1909484women5.jpg', 'women', 'sandals', 11, 'grey', 750, '2016-10-16', '11:59:18 pm'),
(19, '../images/494995women6.jpg', 'women', 'shoes', 10, 'red', 1050, '2016-10-17', '12:00:15 am'),
(20, '../images/1784362men10.jpg', 'men', 'sandals', 15, 'choclate', 1250, '2016-10-17', '12:23:18 am'),
(21, '../images/8419189men11.jpg', 'men', 'sandals', 14, 'wooden', 950, '2016-10-17', '12:23:59 am'),
(22, '../images/5834045men14.jpg', 'men', 'sandals', 17, 'green', 1250, '2016-10-17', '12:24:35 am'),
(23, '../images/3897094men15.jpg', 'men', 'sandals', 15, 'choclate', 1450, '2016-10-17', '12:25:11 am'),
(25, '../images/6687316men1.jpg', 'men', 'shoes', 17, 'wooden', 2100, '2016-10-17', '12:27:35 am'),
(26, '../images/5028686men2.jpg', 'men', 'shoes', 16, 'white', 1850, '2016-10-17', '12:31:10 am'),
(27, '../images/4706726men3.jpg', 'men', 'shoes', 15, 'maroon', 1950, '2016-10-17', '12:31:40 am'),
(28, '../images/5738220men17.jpg', 'men', 'shoes', 17, 'blue', 3200, '2016-10-17', '12:32:31 am'),
(29, '../images/14648men18.jpg', 'men', 'shoes', 15, 'light blue', 2100, '2016-10-17', '12:33:02 am'),
(30, '../images/8419189men5.jpg', 'men', 'converse', 18, 'grey', 2250, '2016-10-17', '12:34:30 am'),
(31, '../images/5834045men6.jpg', 'men', 'converse', 15, 'light blue', 2500, '2016-10-17', '12:35:14 am'),
(32, '../images/3897094men7.jpg', 'men', 'converse', 16, 'grey black', 2150, '2016-10-17', '12:35:45 am'),
(33, '../images/7864074men8.jpg', 'men', 'converse', 19, 'army', 2450, '2016-10-17', '12:36:36 am'),
(35, '../images/57382207412109men12.jpg', 'men', 'sandals', 15, 'black', 2150, '2016-10-17', '12:42:00 am'),
(36, '../images/7404785men9.jpg', 'men', 'converse', 15, 'black', 2150, '2016-10-17', '12:54:48 am'),
(37, '../images/6336975kid1.jpg', 'kid', 'punjabi', 10, 'blue', 750, '2017-04-20', '05:55:23 am'),
(38, '../images/1273193kid4.jpg', 'kid', 'punjabi', 11, 'black', 650, '2017-04-20', '06:11:02 am'),
(39, '../images/5670471kid2.jpg', 'kid', 'punjabi', 7, 'feroza', 680, '2017-04-20', '06:11:40 am'),
(40, '../images/8265686punjabi1.jpg', 'men', 'punjabi', 38, 'skyblue', 1750, '2017-04-20', '06:21:51 am'),
(41, '../images/3945922punjabi2.jpg', 'men', 'punjabi', 40, 'blue', 1350, '2017-04-20', '06:22:25 am'),
(42, '../images/6060485punjabi4.jpg', 'men', 'punjabi', 36, 'skyblue', 1250, '2017-04-20', '06:23:16 am'),
(43, '../images/141601cyclet.jpg', 'men', 't-shirt', 38, 'navyblue', 280, '2017-04-20', '06:24:09 am'),
(44, '../images/6701965polo5.png', 'men', 'polo-t', 38, 'whiteblue', 550, '2017-04-20', '06:25:14 am'),
(45, '../images/9125366shirts1.jpg', 'men', 'shirt', 40, 'blue', 1150, '2017-04-20', '06:26:00 am'),
(46, '../images/1216430polo5.png', 'men', 'polo', 38, 'whiteblue', 550, '2017-04-20', '06:32:47 am'),
(47, '../images/3744812mbag6.jpg', 'men', 'bag', 10, 'maroon', 1450, '2017-04-20', '07:00:42 am'),
(48, '../images/8358154mbag4.jpg', 'men', 'bag', 10, 'lather', 1800, '2017-04-20', '07:01:33 am'),
(49, '../images/431213mbag5.jpg', 'men', 'bag', 11, 'blue', 1500, '2017-04-20', '07:02:16 am'),
(50, '../images/6044921wbag1.jpg', 'women', 'bag', 21, 'grey', 750, '2017-04-20', '10:41:55 am'),
(51, '../images/4602050kids5.jpg', 'kid', 'shoes', 10, 'whiteblue', 450, '2017-04-20', '11:23:49 am');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
