<section id="footer">
    <div class="container">
	<div class="row">
            <div class="col-sm-3 col-md-3">
		<div class="footer-address">
                    <i class="fa fa-map-marker" aria-hidden="true"></i><span>19/A,Coatbari,Comilla</span><br>
                    <i class="fa fa-phone" aria-hidden="true"></i><span>+8801516184740</span><br>
                    <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i><span>fortunabd@gmail.com</span><br></a>
		</div>
            </div>
            <div class="col-sm-5 col-md-5">
		<div class="footer-text text-right">
                    <p>Copyright @ 2016, design by Nahid Naim</p>
		</div>
            </div>
            <div class="col-sm-4 col-md-4">
		<div class="footer-icon pull-right">
                    <i class="fa fa-facebook"></i>
                    <i class="fa fa-twitter"></i>
                    <i class="fa fa-linkedin"></i>
                    <i class="fa fa-google-plus"></i>
		</div>
            </div>
	</div>
    </div>
</section>
