<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fortuna</title>
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet" type="text/css" />
  </head>
  
<header>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mynav" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Fortuna</a>
            </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="mynav">
                <ul class="nav navbar-nav">
                    <li class="dropdown">
                        <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Kids
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="kids-shoes.php">Shoes</a></li>
                            <li><a href="kids-converse.php">converse</a></li>
                            <li><a href="kids-sandals.php">sandals</a></li>
                            <li><a href="kids-punjabi.php">Punjabi</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Women
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="women-converse.php">Converse</a></li>
                            <li><a href="women-shoes.php">Shoes</a></li>
                            <li><a href="women-sandal.php">Sandals</a></li>
                            <li class="disabled"><a href="#">Women Accessories</a></li>
                            <li><a href="women-bag.php">Bags</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Men
                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li class="disabled"><a href="#">Men Clothing</a></li>
                            <li><a href="punjabi.php">Punjabi</a></li>
                            <li><a href="shirt.php">Shirts</a></li>
                            <li><a href="polo.php">Polo T-shirts</a></li>
                            <li><a href="t-shirt.php">T-shirts</a></li>
                            <li class="disabled"><a href="#">Men Shoes</a></li>
                            <li><a href="converse.php">Converse</a></li>
                            <li><a href="shoes.php">Shoes</a></li>
                            <li><a href="sandals.php">Sandals</a></li>
                            <li class="disabled"><a href="#">Men Accessories</a></li>
                            <li><a href="man-bag.php">Bags</a></li>
                        </ul>
                    </li>
                </ul>
                <form class="navbar-form navbar-left" method='post' action='search.php' id='register' enctype='multipart/form-data'>
                    <div class="form-group">
                        <input type="search" name='name' class="form-control" placeholder="Search">
                    </div>
                    <input type='submit' value='Submit' name='search' class='btn btn-default'/>
                </form>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="customer_registration.php">Be a Member</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div>
        </div><!-- /.container-fluid -->
    </nav>
</header>
